import os
import cv2
import glob
import random
import argparse
import face_recognize.cv_tools as cv_tools
import face_recognize.dlib_tools as dlib_tools
import numpy as np
import dlib

class FaceRecognition:
    """
    面部识别, 通过获取摄像头/图片 中的人物和已有的数据对比确定是否是同一个人
    """
    def __init__(self):
        self.csv_path = 'face_recognize/feature'
        self.all_load_feature = []
        self.detector = dlib_tools.get_detector()
        self.predictor = dlib_tools.get_predictor()
        self.model = dlib_tools.get_face_model()
        self.load_face_feature()

    def load_face_feature(self):
        all_csv = glob.glob(self.csv_path + '/*.csv')
        for filename in all_csv:
            array = np.loadtxt(filename, delimiter=',')
            self.all_load_feature.append(array)

    def face_compare(self, face_image, box):
        h, w = face_image.shape[0], face_image.shape[1]
        rgb_image = cv_tools.bgr2rgb(face_image)
        im_shape = rgb_image.shape
        im_height = im_shape[0]
        im_width = im_shape[1]

        left = box[1] * w
        right = box[3]* w
        bottom = box[2]* h
        top = box[0]* h
        # 创建rectangle对象,四个参数分别为左上角点位置，与右下角点的位置
        face = dlib.rectangle(int(left), int(top), int(right), int(bottom))

        feature = self.face_feature(rgb_image, face)
        issame = -1
        for i in range(len(self.all_load_feature)):
            csv_feature = self.all_load_feature[i]
            same = self.face_recogition(feature, csv_feature)
            if same:
                issame = 1
                break
            else:
                continue

        return issame

    def face_feature(self, image, face):
        array = np.array([])
        shape = self.predictor(image, face)
        face_desc = self.model.compute_face_descriptor(image, shape)
        for _, desc in enumerate(face_desc):
            array = np.append(array, desc)
        return array

    def face_recogition(self, face1, face2):
        distance = np.linalg.norm(face1- face2)
        if(distance < 0.5):
            return True
        else:
            return False

