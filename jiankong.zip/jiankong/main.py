import cv2
from face_detection.face_detect import Face_detection
from face_recognize.face_recognize import FaceRecognition
from face_tracker.face_track import Face_track
from people_detection.people_detect import People_detect
import time
import winsound
import numpy as np
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
import face_recognize.cv_tools as cv_tools

def isin(box1, box2): #array(4) box1:face   box2:people
    t1, l1, b1, r1 = box1
    t2, l2, b2, r2 = box2
    if b1 < b2 and l1 > l2 and t1 > t2 and r1 < r2:
        return True
    else:
        return False

def cal_chonghe(box1, box2):
    y1, x1, b1, r1 = box1
    y2, x2, b2, r2 = box2
    w1 = r1 - x1
    w2 = r2 - x2
    h1 = b1 - y1
    h2 = b2 - y2
    endx = max(x1 + w1, x2 + w2)
    startx = min(x1, x2)
    width = w1 + w2 - (endx - startx)  # 重叠部分宽
    endy = max(y1 + h1, y2 + h2)
    starty = min(y1, y2)
    height = h1 + h2 - (endy - starty)  # 重叠部分高
    if width > 0 and height > 0:
        area = width * height;  # 重叠部分面积
        area1 = w1 * h1
        area2 = w2 * h2
        ratio = 1.0 * area / (area1 + area2 - area);
        return ratio
    else:
        # 不重叠：算出来的width或height小于等于0
        return 0.0

def main():
    people_detection = People_detect()
    face_detection = Face_detection()
    face_recognition = FaceRecognition()
    face_tracker = Face_track()

    cap = cv2.VideoCapture(0)
    count = 0

    dete_peoples = [] # t, l, b, r 
    dete_faces = [] # t, l, b, r 
    dete_ishost = []
    with people_detection.detection_graph.as_default():
            with tf.Session(graph=people_detection.detection_graph) as sess:
                while True:
                    ret, image = cap.read()
                    if ret is False:
                        break
                    if count != 2:
                        count += 1
                        for i in range(len(dete_peoples)):
                            people_box = dete_peoples[i]
                            face_box = dete_faces[i]
                            ishost = dete_ishost[i]
                            cv2.rectangle(image, pt1=(int(people_box[1] * w), int(people_box[2] * h)), pt2=(int(people_box[3] * w), int(people_box[0] * h)), color=(0, 255, 0), thickness=2)
                            cv2.rectangle(image, pt1=(int(face_box[1] * w), int(face_box[2] * h)), pt2=(int(face_box[3] * w), int(face_box[0] * h)), color=(0, 0, 255), thickness=2)
                            if ishost == 1:
                                cv_tools.putText(image, "Yes!", location=(int(people_box[1] * w), int(people_box[0] * h)), color=(0, 0, 255))
                            elif ishost < 0:
                                cv_tools.putText(image, "No!", location=(int(people_box[1] * w), int(people_box[0] * h)), color=(0, 0, 255))
                            else:
                                cv_tools.putText(image, "Unknow!", location=(int(people_box[1] * w), int(people_box[0] * h)), color=(0, 0, 255))
                        continue
                    count = 0
                    image = cv2.flip(image, 1)
                    h, w = image.shape[0], image.shape[1]
                    people_boxes, people_num = people_detection.detect(image, sess) # t, l, b, r (n,4) 0~1
                    face_boxes, face_num = face_detection.detect(image) # t, l, b, r (n,4) 0~1

                    dete_peoples = [] # t, l, b, r 
                    dete_faces = [] # t, l, b, r 
                    dete_ishost = []
                    
                    for i in range(len(people_boxes)):
                        match = 0
                        for j in range(len(face_boxes)):
                            if(isin(face_boxes[j], people_boxes[i])):
                                match = 1
                                dete_peoples.append(people_boxes[i])
                                dete_faces.append(face_boxes[j])
                                dete_ishost.append(0)
                                break
                        if match == 0:
                            dete_peoples.append(people_boxes[i])
                            dete_faces.append([0,0,0,0])
                            dete_ishost.append(0)

                    assert len(dete_faces) == len(dete_ishost) and len(dete_faces) == len(dete_peoples)

                    face_tracker.update(image)

                    for i in range(len(dete_faces)):
                        if dete_faces[i] == [0,0,0,0]:
                            find = 0
                            for j in range(len(face_tracker.trackers)):
                                pos = face_tracker.trackers[j].get_position()
                                l = (pos.left())
                                t = (pos.top())
                                r = (pos.right())
                                b = (pos.bottom())
                                tmp_box = [t, l, b, r]
                                chonghe = cal_chonghe(dete_peoples[i] * np.array([h,w,h,w]), tmp_box)
                                if chonghe > 0.5:
                                    dete_ishost[i] = face_tracker.ishost[j]
                                    face_tracker.updateone(image, dete_peoples[i], j, dete_ishost[i])
                                    find = 1
                                    break
                            if find == 0:
                                face_tracker.add_tracker(image, dete_peoples[i], 0)
                                dete_ishost[i] = 0
                        
                            continue
                        has = 0
                        for j in range(len(face_tracker.trackers)):
                            pos = face_tracker.trackers[j].get_position()
                            l = (pos.left())
                            t = (pos.top())
                            r = (pos.right())
                            b = (pos.bottom())
                            tmp_box = np.array([t, l, b, r])
                            if(isin(dete_faces[i] * np.array([h, w, h, w]), tmp_box)):
                                get_host = face_tracker.ishost[j]
                                if get_host == 0:
                                    tmp_host = face_recognition.face_compare(image, dete_faces[i])
                                elif get_host < 0 and get_host > -3:
                                    tmp = face_recognition.face_compare(image, dete_faces[i])
                                    if tmp == 1:
                                        tmp_host = 1
                                    else:
                                        tmp_host = get_host - 1
                                else:
                                    tmp_host = get_host
                                dete_ishost[i] = tmp_host
                                face_tracker.updateone(image, dete_peoples[i], j, tmp_host)
                                has = 1
                                break
                        if has == 0:
                            tmp_ishost = face_recognition.face_compare(image, dete_faces[i])
                            dete_ishost[i] = tmp_ishost
                            face_tracker.add_tracker(image, dete_peoples[i], tmp_ishost)

                    face_tracker.manage(image)

                    print(len(dete_peoples), len(dete_faces), len(face_tracker.trackers))
                    for i in range(len(dete_peoples)):
                        people_box = dete_peoples[i]
                        face_box = dete_faces[i]
                        ishost = dete_ishost[i]
                        cv2.rectangle(image, pt1=(int(people_box[1] * w), int(people_box[2] * h)), pt2=(int(people_box[3] * w), int(people_box[0] * h)), color=(0, 255, 0), thickness=2)
                        cv2.rectangle(image, pt1=(int(face_box[1] * w), int(face_box[2] * h)), pt2=(int(face_box[3] * w), int(face_box[0] * h)), color=(0, 0, 255), thickness=2)
                        if ishost == 1:
                            cv_tools.putText(image, "Yes!", location=(int(people_box[1] * w), int(people_box[0] * h)), color=(0, 0, 255))
                        elif ishost < 0:
                            cv_tools.putText(image, "No!", location=(int(people_box[1] * w), int(people_box[0] * h)), color=(0, 0, 255))
                        else:
                            cv_tools.putText(image, "Unknow!", location=(int(people_box[1] * w), int(people_box[0] * h)), color=(0, 0, 255))

                    # for (t) in (face_tracker.trackers):
                    #     pos = t.get_position() #返回跟踪对象的预测位置

                    #     # 得到位置
                    #     startX = int(pos.left())
                    #     startY = int(pos.top())
                    #     endX = int(pos.right())
                    #     endY = int(pos.bottom())

                    #     # 画出来
                    #     cv2.rectangle(image, (startX, startY), (endX, endY), (0, 220, 220), 2)


                    cv2.imshow('jiankong', image)
                    c = cv2.waitKey(10)
                    if c == 27:
                        break
    cap.release()
    cv2.destroyAllWindows()


if __name__ == '__main__':
    main()


