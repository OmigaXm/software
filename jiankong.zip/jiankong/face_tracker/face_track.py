import numpy as np
import argparse
import dlib
import cv2

class Face_track:
    def __init__(self):
        self.trackers = []
        self.ishost = []

    def add_tracker(self, frame, box, tmp_ishost): #box:(array(4))detections[0, 0, i, 3:7] 0~1 t, l,b, r
        (h, w) = frame.shape[:2]
        width=600
        r = width / float(w)
        dim = (width, int(h * r))
        frame = cv2.resize(frame, dim, interpolation=cv2.INTER_AREA)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB) #OpenCV的颜色通道是BGR的，但是深度学习的框架是RGB的，做一个转换 

        box = box * np.array([h, w, h, w]) #将之还原为原始坐标
        (startY, startX, endY, endX) = box.astype("int")

        t = dlib.correlation_tracker() #实例化方法
        rect = dlib.rectangle(int(startX), int(startY), int(endX), int(endY)) #将之做成一个框
        t.start_track(rgb, rect) #开始追踪，传入当前图像以及检测到的物体的框框
        self.trackers.append(t) #保存追踪的结果
        self.ishost.append(tmp_ishost)

    def update(self, frame):
        if(len(self.trackers) == 0):
            return
        (h, w) = frame.shape[:2]
        width=600
        r = width / float(w)
        dim = (width, int(h * r))
        frame = cv2.resize(frame, dim, interpolation=cv2.INTER_AREA)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB) #OpenCV的颜色通道是BGR的，但是深度学习的框架是RGB的，做一个转换

        for t in self.trackers:
            t.update(rgb)# 这个trackers是上一帧图像检测出物体对应的追踪器，要更新对应这一帧的图像

    def manage(self, image):
        h, w = image.shape[0], image.shape[1]
        size = len(self.trackers)

        i = 0
        while i < size:
            t = self.trackers[i]
            pos = t.get_position()

            startX = int(pos.left())
            startY = int(pos.top())
            endX = int(pos.right())
            endY = int(pos.bottom())

            if endX > w * 19 / 20 or startX < w / 20:
                del self.trackers[i]
                del self.ishost[i]
                size = size -1 
                i -= 1
            i += 1

    def updateone(self, frame, box, j, tmp_host):
        (h, w) = frame.shape[:2]
        width=600
        r = width / float(w)
        dim = (width, int(h * r))
        frame = cv2.resize(frame, dim, interpolation=cv2.INTER_AREA)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB) #OpenCV的颜色通道是BGR的，但是深度学习的框架是RGB的，做一个转换 

        box = box * np.array([h, w, h, w]) #将之还原为原始坐标 t l b r
        (startY, startX, endY, endX) = box.astype("int")

        t = dlib.correlation_tracker() #实例化方法
        rect = dlib.rectangle(int(startX), int(startY), int(endX), int(endY)) #将之做成一个框
        t.start_track(rgb, rect) #开始追踪，传入当前图像以及检测到的物体的框框
        self.trackers[j] = t
        self.ishost[j] =tmp_host
                        
        
            





