import cv2
import numpy as np

class Face_detection:
    def __init__(self):
        model_bin = "face_detection/opencv_face_detector_uint8.pb"
        config_text = "face_detection/opencv_face_detector.pbtxt"
        self.net = cv2.dnn.readNetFromTensorflow(model_bin, config=config_text)
        self.net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
        self.net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)

    def detect(self,image):
        h, w = image.shape[:2]
        blobImage = cv2.dnn.blobFromImage(image, 1.0, (300, 300), (104.0, 177.0, 123.0), False, False);
        self.net.setInput(blobImage)
        cvOut = self.net.forward()

        cut_boxes = []
        newi = 0
        for detection in cvOut[0,0,:,:]: # l, t, r, b 
            score = float(detection[2]) #  3 4 5 6
            objIndex = int(detection[1])
            if score > 0.5 and detection[3]  > 1 / 20 and detection[5] < 19 / 20:
                cut_boxes.append([detection[4], detection[3], detection[6], detection[5]])
                newi += 1
        
        
        return cut_boxes, newi # t, l, b, r