import os
import sys
import tarfile
import cv2
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
import numpy as np
import cv2
from people_detection.utils import label_map_util
from people_detection.utils import visualization_utils as vis_util

class People_detect:
    def __init__(self):
        PATH_TO_FROZEN_GRAPH =  'people_detection/ssd_mobilenet_v1_coco_2018_01_28/frozen_inference_graph.pb'
        PATH_TO_LABELS = os.path.join('people_detection/data', 'mscoco_label_map.pbtxt')

        self.NUM_CLASSES = 90
        
        self.detection_graph = tf.Graph()
        with self.detection_graph.as_default():
            od_graph_def = tf.GraphDef()
            with tf.gfile.GFile(PATH_TO_FROZEN_GRAPH, 'rb') as fid:
                serialized_graph = fid.read()
                od_graph_def.ParseFromString(serialized_graph)
                tf.import_graph_def(od_graph_def, name='')

        label_map = label_map_util.load_labelmap(PATH_TO_LABELS)
        categorys = label_map_util.convert_label_map_to_categories(label_map,max_num_classes=self.NUM_CLASSES,use_display_name=True)
        self.categorys_index = label_map_util.create_category_index(categorys)

    def detect(self,image, sess):
        h, w = image.shape[0], image.shape[1]
        image_np_expanded = np.expand_dims(image,axis = 0)
        image_tensor = self.detection_graph.get_tensor_by_name('image_tensor:0')
        boxes = self.detection_graph.get_tensor_by_name('detection_boxes:0')
        scores = self.detection_graph.get_tensor_by_name('detection_scores:0')
        classes = self.detection_graph.get_tensor_by_name('detection_classes:0')
        num_detections = self.detection_graph.get_tensor_by_name('num_detections:0')
        (boxes,scores,classes,num_detections) = sess.run([boxes,scores,classes,\
                                    num_detections],feed_dict={image_tensor:image_np_expanded})
        cut_boxes = []
        new_i = 0
        for i in range(int(num_detections[0])):
            if classes[0][i] == 1 and scores[0][i] >= 0.5 and boxes[0][i][1] > 1 / 20 and boxes[0][i][3] <  19 / 20 :
                cut_boxes.append(boxes[0][i])
                new_i += 1
        return cut_boxes, new_i #t, l, b, r