#导入工具包
import numpy as np
import argparse
import dlib
import cv2

# SSD标签
CLASSES = ["background", "aeroplane", "bicycle", "bird", "boat",
	"bottle", "bus", "car", "cat", "chair", "cow", "diningtable",
	"dog", "horse", "motorbike", "person", "pottedplant", "sheep",
	"sofa", "train", "tvmonitor"]

model_bin = "face_detection/opencv_face_detector_uint8.pb"
config_text = "face_detection/opencv_face_detector.pbtxt"

net = cv2.dnn.readNetFromTensorflow(model_bin,config=config_text)

# 初始化
vs = cv2.VideoCapture(0)

# 一会要追踪多个目标
trackers = [] #追踪器列表
labels = []

while True:
    # 读取一帧
    (grabbed, frame) = vs.read()
    frame = cv2.flip(frame, 1)
    # 是否是最后了
    if frame is None:
        break

    # 预处理操作
    (h, w) = frame.shape[:2]
    width=600
    r = width / float(w)
    dim = (width, int(h * r))
    frame = cv2.resize(frame, dim, interpolation=cv2.INTER_AREA)
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB) #OpenCV的颜色通道是BGR的，但是深度学习的框架是RGB的，做一个转换

    # 先检测 再追踪
    if len(trackers) == 0: #代表是第一次检测
        print('diyici')
        # 获取blob数据
        (h, w) = frame.shape[:2]
        blob = cv2.dnn.blobFromImage(frame, 1.0, (300, 300), [104, 117, 123], False, False)
        #输入参数：图像，缩放因子，宽高，均值（要做一个减均值的操作）
        # 得到检测结果
        net.setInput(blob) #将输入数据传入模型
        detections = net.forward() #前向传播
        #检测到的结果有多个，不一定都是人（我们需要的东西），我已我们要对检测结果进行筛选
        # 遍历得到的检测结果
        for i in np.arange(0, detections.shape[2]):
            # 能检测到多个结果，只保留概率高的
            confidence = detections[0, 0, i, 2]
            #SSD框架是同时完成检测与分类的。检测的结果中也有概率和匹配的物体id
            #取出概率值，与阈值比较，若大于阈值就取出该概率值对应的物体id
            # 过滤
            if confidence > 0.5:
                # extract the index of the class label from the
                # detections list
                idx = int(detections[0, 0, i, 1])
                label = CLASSES[idx]
                #提取出标签对应的物体名称，如果不是人的话，就舍弃
                # 只保留人的
                # if CLASSES[idx] != "person":
                # 	continue
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h]) #将之还原为原始坐标
                (startX, startY, endX, endY) = box.astype("int")

                wx = int(endX - startX)
                hy = int(endY - endX)
                # 使用dlib来进行目标追踪
                t = dlib.correlation_tracker() #实例化方法
                rect = dlib.rectangle(int(startX), int(startY), int(endX), int(endY)) #将之做成一个框
                t.start_track(rgb, rect) #开始追踪，传入当前图像以及检测到的物体的框框
                #该对象将开始跟踪给定图像的边界框内的物体。也就是说，如果您对随后的视频帧调用update()，
                # 那么它将尝试跟踪边框内对象的位置。
                # 保存结果
                labels.append(label) #保存标签
                trackers.append(t) #保存追踪的结果

                cv2.rectangle(frame, (startX, startY), (endX, endY), (0, 220, 220), 2)
                cv2.putText(frame, label, (startX, startY - 15),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 0), 2)

                

    # 如果已经有了框，就可以直接追踪了
    else:
        print(len(trackers))

        for t in (trackers):  
            pos = t.get_position() #返回跟踪对象的预测位置
            t.update(rgb)
            # 得到位置
            startX = int(pos.left())
            startY = int(pos.top())
            endX = int(pos.right())
            endY = int(pos.bottom())

            print(pos.left(), pos.top(), pos.right(), pos.bottom()) # xmin, ymin, xmax, ymax

            # 画出来
            cv2.rectangle(frame, (startX, startY), (endX, endY), (0, 220, 220), 5)

        每一个追踪器都要进行更新
        for (t, l) in zip(trackers, labels):
            t.update(rgb)# 这个trackers是上一帧图像检测出物体对应的追踪器，要更新对应这一帧的图像
            pos = t.get_position() #返回跟踪对象的预测位置

            # 得到位置
            startX = int(pos.left())
            startY = int(pos.top())
            endX = int(pos.right())
            endY = int(pos.bottom())

            # 画出来
            cv2.rectangle(frame, (startX, startY), (endX, endY), (0, 220, 220), 2)
            cv2.putText(frame, l, (startX, startY - 15),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 0), 2)

    # 显示
    cv2.imshow("Frame", frame)
    key = cv2.waitKey(1) & 0xFF

    # 退出
    if key == 27:
        break

vs.release()
cv2.destroyAllWindows()

